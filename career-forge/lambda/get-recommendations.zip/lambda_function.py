import pandas as pd
import boto3
from botocore.exceptions import ClientError

s3 = boto3.client("s3")
personalize = boto3.client(service_name='personalize')
personalize_runtime = boto3.client(service_name='personalize-runtime')
personalize_events = boto3.client(service_name='personalize-events')
campaign_arn = "arn:aws:personalize:us-east-1:058264466946:campaign/user-personalization-3"

def get_new_recommendations_df_users(recommendations_df, user_id, context):
    
    get_recommendations_response = personalize_runtime.get_recommendations(
        campaignArn = campaign_arn,
        userId = str(user_id),
        context = {
            "resume" : context
        }
    )
    # Build a new dataframe of recommendations
    item_list = get_recommendations_response['itemList']
    recommendation_list = []
    for item in item_list:
        recommendation_list.append(item['itemId'])

    return recommendation_list
    
def lambda_handler(event, context):
    # TODO implement

    user_id = event["user_id"]
    filepath = 'textract/' + str(user_id) + '.pdf.txt'
    try:
        
        resume_info = s3.get_object(Bucket='career-forge-s3-v1', Key=filepath)
        data = resume_info['Body'].read()
        context = str(data)[:1000]
        recommendations_df_users = pd.DataFrame()
        recommendations_df_users = get_new_recommendations_df_users(recommendations_df_users, user_id, context)
        return recommendations_df_users
    except:
        print('error')
    
    